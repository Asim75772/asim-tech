package com.asimtech.myapp;

import android.app.*;import android.os.*;import android.graphics.Color;import android.content.*;import android.net.Uri;import android.view.*;import android.widget.*;

public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,24);root.setBackgroundColor(0xFFF5F7FA);
 TextView header=new TextView(this);header.setText("Madhu Music World");header.setTextSize(24);header.setTextColor(Color.BLACK);header.setGravity(Gravity.CENTER);root.addView(header,new LinearLayout.LayoutParams(-1,-2));
setContentView(root);}
}